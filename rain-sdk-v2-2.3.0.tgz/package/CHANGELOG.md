# Changelog

All notable changes to `rain-sdk-v2` are documented here. This project follows
[Semantic Versioning](https://semver.org/).

## Deprecation policy

APIs slated for removal are marked `@deprecated` in the type declarations for at
least one minor release before they are removed, with the replacement named in
the deprecation notice. Breaking removals land only in a major version.

## [2.3.0] - Developer experience

Additive, non-breaking. Fills in the untyped core data model and adds the
convenience helpers the docs previously pushed onto the caller.

### Added
- **Typed pool DTOs (F-05):** exported `Pool`, `SubPool`, `PaginatedPools`, and
  `TradingModelName`. `getPublicPools` / `getPrivatePools` now return
  `ApiResponse<PaginatedPools>` instead of `unknown`. Socket `*EventData`
  payloads now type their `pool` / `subPool` / `subMarkets` fields as
  `Pool` / `SubPool`. Interfaces carry an index signature, so they are a safe
  superset of the wire (dynamic field access still works).
- **`rain.execute(txs, executor)` (F-07):** sequences the `[approval, main]`
  arrays the builders return — sends each tx and awaits its receipt before the
  next. Pluggable `TxExecutor` (`{ send, wait? }`) adapts to viem, ethers, or
  RainAA. Also exported as the standalone `executeTxs`.
- **`rain.parseAmount` / `rain.formatAmount` (F-14):** convert between
  human-readable amounts and base units using the token's configured decimals
  (no more hand-tracking that USDT is 6 and RAIN is 18).
- **`RAIN_SOCKET_EVENTS` (F-16):** correctly-spelled camelCase aliases for the
  raw wire event names (including the upstream-misspelled `dispute-time-extented`).
- **Token expiry (F-13):** `LoginResult.expiresAt` exposes the decoded JWT `exp`
  (unix seconds) so apps can renew proactively.

## [2.2.0] - Guardrails

Adds fail-fast validation and structured errors. These surface mistakes
synchronously (before broadcast) instead of as on-chain reverts or parsed
strings. Existing `catch (e)` blocks keep working — the new errors extend `Error`.

### Added
- **Build-time parameter validation (F-03):** every transaction builder now
  rejects the documented footguns before encoding — a `deadline` that looks like
  a duration (`< 1_000_000_000`) or is already expired, a `slippageTolerance`
  outside `0–100` (whole percent, not bps), and a 0-based `option`/`selectedOption`
  (options are 1-based). Throws the new `RainValidationError`. Exported helpers:
  `assertDeadline`, `assertSlippage`, `assertOption`.
- **Structured API errors (F-06):** non-2xx REST responses now throw
  `RainApiError` carrying `status`, `endpoint`, `body`, and a stable `code`
  (`NOT_FOUND` | `UNAUTHORIZED` | `FORBIDDEN` | `RATE_LIMITED` | `SERVER_ERROR` |
  `UNKNOWN`) — branch on `err.code` instead of parsing message strings.

### Changed
- **Empty states are no longer errors (F-06):** `getPnlByPoolId` (no position)
  and `getTokenPrice` (non-whitelisted token) now return
  `{ statusCode: 200, data: null }` on a 404 instead of throwing.
- **Deterministic default RPC (F-09):** omitting `rpcUrl` now resolves to a
  single fixed public RPC (previously random per instance). In `production`
  without an `rpcUrl`, the SDK emits a `console.warn` recommending a dedicated
  endpoint.

## [2.1.9] - Correctness patch

Addresses findings from the September 2026 independent technical review. No
behaviour change for correct callers.

### Fixed
- **Missing type exports (F-10):** `SellOptionTxParams`, `EntrySharesResult`,
  `SellProceedsResult`, and `OrderLevelInfo` are now exported from the package
  root, so consumers can annotate their own functions with them.
- **`RainConfig` type honesty (F-04):** `alchemyApiKey` and `paymasterPolicyId`
  are now required in the type — the `RainAA` constructor already threw without
  them. The type now matches runtime behaviour.
- **`smartWalletAddress` optional (F-08):** `LoginParams.smartWalletAddress` is
  now optional and defaults to `walletAddress`, so plain-EOA integrations no
  longer have to pass the address twice.

### Notes
- Two review findings (F-01 reverting order reads, F-02 REST type/wire
  mismatches) require verification against the live dev API/contracts before any
  change and are intentionally not addressed in this release.
